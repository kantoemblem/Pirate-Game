# FreeMovement
FreeMovement mode on FE8U

More details at [here](https://feuniverse.us/t/freemovement-rework-modular-version-updated-with-tutorials/13332)