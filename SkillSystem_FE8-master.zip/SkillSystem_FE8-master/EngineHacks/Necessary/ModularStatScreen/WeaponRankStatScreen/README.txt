Will make Rtext in Stat Screen, Weapon rank & support page only display for unlocked weapons.
Will also display the correct HelptextID for units with either or both magic and physical weapon ranks.
Will only work for up to four weapons.