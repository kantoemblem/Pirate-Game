
void StartTradeMenuTutorialHandCursor(void);
