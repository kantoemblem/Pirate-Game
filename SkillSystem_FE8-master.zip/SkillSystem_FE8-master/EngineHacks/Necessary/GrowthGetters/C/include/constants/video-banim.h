#pragma once

#include "constants/video-global.h"

enum
{
    OBJCHR_BANIM_FACE = 0x40,
};

enum
{
    OBJPAL_BANIM_FACE = 3,
};
