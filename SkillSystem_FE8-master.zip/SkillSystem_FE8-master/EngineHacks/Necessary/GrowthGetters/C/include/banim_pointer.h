#pragma once
// battle animation 0x0
extern int banim_lorm_sp1_modes_bin;
extern char banim_lorm_sp1_motion_o;
extern char banim_lorm_sp1_oam_r_bin;
extern char banim_lorm_sp1_oam_l_bin;
extern char banim_lorm_sp1_agbpal;
// battle animation 0x1
extern int banim_lorm_sp1_2_modes_bin;
extern char banim_lorm_sp1_2_motion_o;
extern char banim_lorm_sp1_2_oam_r_bin;
extern char banim_lorm_sp1_2_oam_l_bin;
extern char banim_lorm_sp1_2_agbpal;
// battle animation 0x2
extern int banim_lorf_sw1_modes_bin;
extern char banim_lorf_sw1_motion_o;
extern char banim_lorf_sw1_oam_r_bin;
extern char banim_lorf_sw1_oam_l_bin;
extern char banim_lorf_sw1_agbpal;
// battle animation 0x3
extern int banim_lorf_sw1_2_modes_bin;
extern char banim_lorf_sw1_2_motion_o;
extern char banim_lorf_sw1_2_oam_r_bin;
extern char banim_lorf_sw1_2_oam_l_bin;
extern char banim_lorf_sw1_2_agbpal;
// battle animation 0x4
extern int banim_lomm_sp1_modes_bin;
extern char banim_lomm_sp1_motion_o;
extern char banim_lomm_sp1_oam_r_bin;
extern char banim_lomm_sp1_oam_l_bin;
extern char banim_lomm_sp1_agbpal;
// battle animation 0x5
extern int banim_lorf_sw1_3_modes_bin;
extern char banim_lorf_sw1_3_motion_o;
extern char banim_lorf_sw1_3_oam_r_bin;
extern char banim_lorf_sw1_3_oam_l_bin;
extern char banim_lorf_sw1_3_agbpal;
// battle animation 0x6
extern int banim_lomm_sp1_2_modes_bin;
extern char banim_lomm_sp1_2_motion_o;
extern char banim_lomm_sp1_2_oam_r_bin;
extern char banim_lomm_sp1_2_oam_l_bin;
extern char banim_lomm_sp1_2_agbpal;
// battle animation 0x7
extern int banim_lomf_sw1_modes_bin;
extern char banim_lomf_sw1_motion_o;
extern char banim_lomf_sw1_oam_r_bin;
extern char banim_lomf_sw1_oam_l_bin;
extern char banim_lomf_sw1_agbpal;
// battle animation 0x8
extern int banim_lorf_sw1_4_modes_bin;
extern char banim_lorf_sw1_4_motion_o;
extern char banim_lorf_sw1_4_oam_r_bin;
extern char banim_lorf_sw1_4_oam_l_bin;
extern char banim_lorf_sw1_4_agbpal;
// battle animation 0x9
extern int banim_lomf_sw1_2_modes_bin;
extern char banim_lomf_sw1_2_motion_o;
extern char banim_lomf_sw1_2_oam_r_bin;
extern char banim_lomf_sw1_2_oam_l_bin;
extern char banim_lomf_sw1_2_agbpal;
// battle animation 0xA
extern int banim_merm_sw1_modes_bin;
extern char banim_merm_sw1_motion_o;
extern char banim_merm_sw1_oam_r_bin;
extern char banim_merm_sw1_oam_l_bin;
extern char banim_merm_sw1_agbpal;
// battle animation 0xB
extern int banim_merm_sw1_2_modes_bin;
extern char banim_merm_sw1_2_motion_o;
extern char banim_merm_sw1_2_oam_r_bin;
extern char banim_merm_sw1_2_oam_l_bin;
extern char banim_merm_sw1_2_agbpal;
// battle animation 0xC
extern int banim_bram_sw1_modes_bin;
extern char banim_bram_sw1_motion_o;
extern char banim_bram_sw1_oam_r_bin;
extern char banim_bram_sw1_oam_l_bin;
extern char banim_bram_sw1_agbpal;
// battle animation 0xD
extern int banim_bram_sw1_2_modes_bin;
extern char banim_bram_sw1_2_motion_o;
extern char banim_bram_sw1_2_oam_r_bin;
extern char banim_bram_sw1_2_oam_l_bin;
extern char banim_bram_sw1_2_agbpal;
// battle animation 0xE
extern int banim_bram_sw1_3_modes_bin;
extern char banim_bram_sw1_3_motion_o;
extern char banim_bram_sw1_3_oam_r_bin;
extern char banim_bram_sw1_3_oam_l_bin;
extern char banim_bram_sw1_3_agbpal;
// battle animation 0xF
extern int banim_bram_sw1_4_modes_bin;
extern char banim_bram_sw1_4_motion_o;
extern char banim_bram_sw1_4_oam_r_bin;
extern char banim_bram_sw1_4_oam_l_bin;
extern char banim_bram_sw1_4_agbpal;
// battle animation 0x10
extern int banim_myrm_sw1_modes_bin;
extern char banim_myrm_sw1_motion_o;
extern char banim_myrm_sw1_oam_r_bin;
extern char banim_myrm_sw1_oam_l_bin;
extern char banim_myrm_sw1_agbpal;
// battle animation 0x11
extern int banim_myrm_sw1_2_modes_bin;
extern char banim_myrm_sw1_2_motion_o;
extern char banim_myrm_sw1_2_oam_r_bin;
extern char banim_myrm_sw1_2_oam_l_bin;
extern char banim_myrm_sw1_2_agbpal;
// battle animation 0x12
extern int banim_myrf_sw1_modes_bin;
extern char banim_myrf_sw1_motion_o;
extern char banim_myrf_sw1_oam_r_bin;
extern char banim_myrf_sw1_oam_l_bin;
extern char banim_myrf_sw1_agbpal;
// battle animation 0x13
extern int banim_myrf_sw1_2_modes_bin;
extern char banim_myrf_sw1_2_motion_o;
extern char banim_myrf_sw1_2_oam_r_bin;
extern char banim_myrf_sw1_2_oam_l_bin;
extern char banim_myrf_sw1_2_agbpal;
// battle animation 0x14
extern int banim_swmm_sw1_modes_bin;
extern char banim_swmm_sw1_motion_o;
extern char banim_swmm_sw1_oam_r_bin;
extern char banim_swmm_sw1_oam_l_bin;
extern char banim_swmm_sw1_agbpal;
// battle animation 0x15
extern int banim_swmm_sw1_2_modes_bin;
extern char banim_swmm_sw1_2_motion_o;
extern char banim_swmm_sw1_2_oam_r_bin;
extern char banim_swmm_sw1_2_oam_l_bin;
extern char banim_swmm_sw1_2_agbpal;
// battle animation 0x16
extern int banim_swmf_sw1_modes_bin;
extern char banim_swmf_sw1_motion_o;
extern char banim_swmf_sw1_oam_r_bin;
extern char banim_swmf_sw1_oam_l_bin;
extern char banim_swmf_sw1_agbpal;
// battle animation 0x17
extern int banim_swmf_sw1_2_modes_bin;
extern char banim_swmf_sw1_2_motion_o;
extern char banim_swmf_sw1_2_oam_r_bin;
extern char banim_swmf_sw1_2_oam_l_bin;
extern char banim_swmf_sw1_2_agbpal;
// battle animation 0x18
extern int banim_figm_ax1_modes_bin;
extern char banim_figm_ax1_motion_o;
extern char banim_figm_ax1_oam_r_bin;
extern char banim_figm_ax1_oam_l_bin;
extern char banim_figm_ax1_agbpal;
// battle animation 0x19
extern int banim_figm_ax1_2_modes_bin;
extern char banim_figm_ax1_2_motion_o;
extern char banim_figm_ax1_2_oam_r_bin;
extern char banim_figm_ax1_2_oam_l_bin;
extern char banim_figm_ax1_2_agbpal;
// battle animation 0x1A
extern int banim_figm_ax1_3_modes_bin;
extern char banim_figm_ax1_3_motion_o;
extern char banim_figm_ax1_3_oam_r_bin;
extern char banim_figm_ax1_3_oam_l_bin;
extern char banim_figm_ax1_3_agbpal;
// battle animation 0x1B
extern int banim_warm_ax1_modes_bin;
extern char banim_warm_ax1_motion_o;
extern char banim_warm_ax1_oam_r_bin;
extern char banim_warm_ax1_oam_l_bin;
extern char banim_warm_ax1_agbpal;
// battle animation 0x1C
extern int banim_warm_ax1_2_modes_bin;
extern char banim_warm_ax1_2_motion_o;
extern char banim_warm_ax1_2_oam_r_bin;
extern char banim_warm_ax1_2_oam_l_bin;
extern char banim_warm_ax1_2_agbpal;
// battle animation 0x1D
extern int banim_warm_ar1_modes_bin;
extern char banim_warm_ar1_motion_o;
extern char banim_warm_ar1_oam_r_bin;
extern char banim_warm_ar1_oam_l_bin;
extern char banim_warm_ar1_agbpal;
// battle animation 0x1E
extern int banim_warm_ax1_3_modes_bin;
extern char banim_warm_ax1_3_motion_o;
extern char banim_warm_ax1_3_oam_r_bin;
extern char banim_warm_ax1_3_oam_l_bin;
extern char banim_warm_ax1_3_agbpal;
// battle animation 0x1F
extern int banim_banm_ax1_modes_bin;
extern char banim_banm_ax1_motion_o;
extern char banim_banm_ax1_oam_r_bin;
extern char banim_banm_ax1_oam_l_bin;
extern char banim_banm_ax1_agbpal;
// battle animation 0x20
extern int banim_banm_ax1_2_modes_bin;
extern char banim_banm_ax1_2_motion_o;
extern char banim_banm_ax1_2_oam_r_bin;
extern char banim_banm_ax1_2_oam_l_bin;
extern char banim_banm_ax1_2_agbpal;
// battle animation 0x21
extern int banim_banm_ax1_3_modes_bin;
extern char banim_banm_ax1_3_motion_o;
extern char banim_banm_ax1_3_oam_r_bin;
extern char banim_banm_ax1_3_oam_l_bin;
extern char banim_banm_ax1_3_agbpal;
// battle animation 0x22
extern int banim_brsm_ax1_modes_bin;
extern char banim_brsm_ax1_motion_o;
extern char banim_brsm_ax1_oam_r_bin;
extern char banim_brsm_ax1_oam_l_bin;
extern char banim_brsm_ax1_agbpal;
// battle animation 0x23
extern int banim_brsm_ax1_2_modes_bin;
extern char banim_brsm_ax1_2_motion_o;
extern char banim_brsm_ax1_2_oam_r_bin;
extern char banim_brsm_ax1_2_oam_l_bin;
extern char banim_brsm_ax1_2_agbpal;
// battle animation 0x24
extern int banim_brsm_ax1_3_modes_bin;
extern char banim_brsm_ax1_3_motion_o;
extern char banim_brsm_ax1_3_oam_r_bin;
extern char banim_brsm_ax1_3_oam_l_bin;
extern char banim_brsm_ax1_3_agbpal;
// battle animation 0x25
extern int banim_arcm_ar1_modes_bin;
extern char banim_arcm_ar1_motion_o;
extern char banim_arcm_ar1_oam_r_bin;
extern char banim_arcm_ar1_oam_l_bin;
extern char banim_arcm_ar1_agbpal;
// battle animation 0x26
extern int banim_arcm_ar1_2_modes_bin;
extern char banim_arcm_ar1_2_motion_o;
extern char banim_arcm_ar1_2_oam_r_bin;
extern char banim_arcm_ar1_2_oam_l_bin;
extern char banim_arcm_ar1_2_agbpal;
// battle animation 0x27
extern int banim_arcf_ar1_modes_bin;
extern char banim_arcf_ar1_motion_o;
extern char banim_arcf_ar1_oam_r_bin;
extern char banim_arcf_ar1_oam_l_bin;
extern char banim_arcf_ar1_agbpal;
// battle animation 0x28
extern int banim_arcf_ar1_2_modes_bin;
extern char banim_arcf_ar1_2_motion_o;
extern char banim_arcf_ar1_2_oam_r_bin;
extern char banim_arcf_ar1_2_oam_l_bin;
extern char banim_arcf_ar1_2_agbpal;
// battle animation 0x29
extern int banim_snim_ar1_modes_bin;
extern char banim_snim_ar1_motion_o;
extern char banim_snim_ar1_oam_r_bin;
extern char banim_snim_ar1_oam_l_bin;
extern char banim_snim_ar1_agbpal;
// battle animation 0x2A
extern int banim_snim_ar1_2_modes_bin;
extern char banim_snim_ar1_2_motion_o;
extern char banim_snim_ar1_2_oam_r_bin;
extern char banim_snim_ar1_2_oam_l_bin;
extern char banim_snim_ar1_2_agbpal;
// battle animation 0x2B
extern int banim_snif_ar1_modes_bin;
extern char banim_snif_ar1_motion_o;
extern char banim_snif_ar1_oam_r_bin;
extern char banim_snif_ar1_oam_l_bin;
extern char banim_snif_ar1_agbpal;
// battle animation 0x2C
extern int banim_snif_ar1_2_modes_bin;
extern char banim_snif_ar1_2_motion_o;
extern char banim_snif_ar1_2_oam_r_bin;
extern char banim_snif_ar1_2_oam_l_bin;
extern char banim_snif_ar1_2_agbpal;
// battle animation 0x2D
extern int banim_form_sw1_modes_bin;
extern char banim_form_sw1_motion_o;
extern char banim_form_sw1_oam_r_bin;
extern char banim_form_sw1_oam_l_bin;
extern char banim_form_sw1_agbpal;
// battle animation 0x2E
extern int banim_form_ar1_modes_bin;
extern char banim_form_ar1_motion_o;
extern char banim_form_ar1_oam_r_bin;
extern char banim_form_ar1_oam_l_bin;
extern char banim_form_ar1_agbpal;
// battle animation 0x2F
extern int banim_form_sw1_2_modes_bin;
extern char banim_form_sw1_2_motion_o;
extern char banim_form_sw1_2_oam_r_bin;
extern char banim_form_sw1_2_oam_l_bin;
extern char banim_form_sw1_2_agbpal;
// battle animation 0x30
extern int banim_forf_sw1_modes_bin;
extern char banim_forf_sw1_motion_o;
extern char banim_forf_sw1_oam_r_bin;
extern char banim_forf_sw1_oam_l_bin;
extern char banim_forf_sw1_agbpal;
// battle animation 0x31
extern int banim_forf_ar1_modes_bin;
extern char banim_forf_ar1_motion_o;
extern char banim_forf_ar1_oam_r_bin;
extern char banim_forf_ar1_oam_l_bin;
extern char banim_forf_ar1_agbpal;
// battle animation 0x32
extern int banim_forf_sw1_2_modes_bin;
extern char banim_forf_sw1_2_motion_o;
extern char banim_forf_sw1_2_oam_r_bin;
extern char banim_forf_sw1_2_oam_l_bin;
extern char banim_forf_sw1_2_agbpal;
// battle animation 0x33
extern int banim_sokm_sp1_modes_bin;
extern char banim_sokm_sp1_motion_o;
extern char banim_sokm_sp1_oam_r_bin;
extern char banim_sokm_sp1_oam_l_bin;
extern char banim_sokm_sp1_agbpal;
// battle animation 0x34
extern int banim_sokm_sp1_2_modes_bin;
extern char banim_sokm_sp1_2_motion_o;
extern char banim_sokm_sp1_2_oam_r_bin;
extern char banim_sokm_sp1_2_oam_l_bin;
extern char banim_sokm_sp1_2_agbpal;
// battle animation 0x35
extern int banim_sokm_sp1_3_modes_bin;
extern char banim_sokm_sp1_3_motion_o;
extern char banim_sokm_sp1_3_oam_r_bin;
extern char banim_sokm_sp1_3_oam_l_bin;
extern char banim_sokm_sp1_3_agbpal;
// battle animation 0x36
extern int banim_sokf_sp1_modes_bin;
extern char banim_sokf_sp1_motion_o;
extern char banim_sokf_sp1_oam_r_bin;
extern char banim_sokf_sp1_oam_l_bin;
extern char banim_sokf_sp1_agbpal;
// battle animation 0x37
extern int banim_sokf_sp1_2_modes_bin;
extern char banim_sokf_sp1_2_motion_o;
extern char banim_sokf_sp1_2_oam_r_bin;
extern char banim_sokf_sp1_2_oam_l_bin;
extern char banim_sokf_sp1_2_agbpal;
// battle animation 0x38
extern int banim_sokf_sp1_3_modes_bin;
extern char banim_sokf_sp1_3_motion_o;
extern char banim_sokf_sp1_3_oam_r_bin;
extern char banim_sokf_sp1_3_oam_l_bin;
extern char banim_sokf_sp1_3_agbpal;
// battle animation 0x39
extern int banim_pakm_sw1_modes_bin;
extern char banim_pakm_sw1_motion_o;
extern char banim_pakm_sw1_oam_r_bin;
extern char banim_pakm_sw1_oam_l_bin;
extern char banim_pakm_sw1_agbpal;
// battle animation 0x3A
extern int banim_pakm_sw1_2_modes_bin;
extern char banim_pakm_sw1_2_motion_o;
extern char banim_pakm_sw1_2_oam_r_bin;
extern char banim_pakm_sw1_2_oam_l_bin;
extern char banim_pakm_sw1_2_agbpal;
// battle animation 0x3B
extern int banim_pakm_sw1_3_modes_bin;
extern char banim_pakm_sw1_3_motion_o;
extern char banim_pakm_sw1_3_oam_r_bin;
extern char banim_pakm_sw1_3_oam_l_bin;
extern char banim_pakm_sw1_3_agbpal;
// battle animation 0x3C
extern int banim_paif_sw1_modes_bin;
extern char banim_paif_sw1_motion_o;
extern char banim_paif_sw1_oam_r_bin;
extern char banim_paif_sw1_oam_l_bin;
extern char banim_paif_sw1_agbpal;
// battle animation 0x3D
extern int banim_paif_sw1_2_modes_bin;
extern char banim_paif_sw1_2_motion_o;
extern char banim_paif_sw1_2_oam_r_bin;
extern char banim_paif_sw1_2_oam_l_bin;
extern char banim_paif_sw1_2_agbpal;
// battle animation 0x3E
extern int banim_paif_sw1_3_modes_bin;
extern char banim_paif_sw1_3_motion_o;
extern char banim_paif_sw1_3_oam_r_bin;
extern char banim_paif_sw1_3_oam_l_bin;
extern char banim_paif_sw1_3_agbpal;
// battle animation 0x3F
extern int banim_armm_sp1_modes_bin;
extern char banim_armm_sp1_motion_o;
extern char banim_armm_sp1_oam_r_bin;
extern char banim_armm_sp1_oam_l_bin;
extern char banim_armm_sp1_agbpal;
// battle animation 0x40
extern int banim_armm_sp1_2_modes_bin;
extern char banim_armm_sp1_2_motion_o;
extern char banim_armm_sp1_2_oam_r_bin;
extern char banim_armm_sp1_2_oam_l_bin;
extern char banim_armm_sp1_2_agbpal;
// battle animation 0x41
extern int banim_armm_sp1_3_modes_bin;
extern char banim_armm_sp1_3_motion_o;
extern char banim_armm_sp1_3_oam_r_bin;
extern char banim_armm_sp1_3_oam_l_bin;
extern char banim_armm_sp1_3_agbpal;
// battle animation 0x42
extern int banim_armm_sp1_4_modes_bin;
extern char banim_armm_sp1_4_motion_o;
extern char banim_armm_sp1_4_oam_r_bin;
extern char banim_armm_sp1_4_oam_l_bin;
extern char banim_armm_sp1_4_agbpal;
// battle animation 0x43
extern int banim_genm_sw1_modes_bin;
extern char banim_genm_sw1_motion_o;
extern char banim_genm_sw1_oam_r_bin;
extern char banim_genm_sw1_oam_l_bin;
extern char banim_genm_sw1_agbpal;
// battle animation 0x44
extern int banim_genm_al1_modes_bin;
extern char banim_genm_al1_motion_o;
extern char banim_genm_al1_oam_r_bin;
extern char banim_genm_al1_oam_l_bin;
extern char banim_genm_al1_agbpal;
// battle animation 0x45
extern int banim_genm_al1_2_modes_bin;
extern char banim_genm_al1_2_motion_o;
extern char banim_genm_al1_2_oam_r_bin;
extern char banim_genm_al1_2_oam_l_bin;
extern char banim_genm_al1_2_agbpal;
// battle animation 0x46
extern int banim_genm_al1_3_modes_bin;
extern char banim_genm_al1_3_motion_o;
extern char banim_genm_al1_3_oam_r_bin;
extern char banim_genm_al1_3_oam_l_bin;
extern char banim_genm_al1_3_agbpal;
// battle animation 0x47
extern int banim_genm_al1_4_modes_bin;
extern char banim_genm_al1_4_motion_o;
extern char banim_genm_al1_4_oam_r_bin;
extern char banim_genm_al1_4_oam_l_bin;
extern char banim_genm_al1_4_agbpal;
// battle animation 0x48
extern int banim_genm_sw1_2_modes_bin;
extern char banim_genm_sw1_2_motion_o;
extern char banim_genm_sw1_2_oam_r_bin;
extern char banim_genm_sw1_2_oam_l_bin;
extern char banim_genm_sw1_2_agbpal;
// battle animation 0x49
extern int banim_genm_al1_5_modes_bin;
extern char banim_genm_al1_5_motion_o;
extern char banim_genm_al1_5_oam_r_bin;
extern char banim_genm_al1_5_oam_l_bin;
extern char banim_genm_al1_5_agbpal;
// battle animation 0x4A
extern int banim_genm_al1_6_modes_bin;
extern char banim_genm_al1_6_motion_o;
extern char banim_genm_al1_6_oam_r_bin;
extern char banim_genm_al1_6_oam_l_bin;
extern char banim_genm_al1_6_agbpal;
// battle animation 0x4B
extern int banim_genm_al1_7_modes_bin;
extern char banim_genm_al1_7_motion_o;
extern char banim_genm_al1_7_oam_r_bin;
extern char banim_genm_al1_7_oam_l_bin;
extern char banim_genm_al1_7_agbpal;
// battle animation 0x4C
extern int banim_genm_al1_8_modes_bin;
extern char banim_genm_al1_8_motion_o;
extern char banim_genm_al1_8_oam_r_bin;
extern char banim_genm_al1_8_oam_l_bin;
extern char banim_genm_al1_8_agbpal;
// battle animation 0x4D
extern int banim_grkm_sw1_modes_bin;
extern char banim_grkm_sw1_motion_o;
extern char banim_grkm_sw1_oam_r_bin;
extern char banim_grkm_sw1_oam_l_bin;
extern char banim_grkm_sw1_agbpal;
// battle animation 0x4E
extern int banim_grkm_sp1_modes_bin;
extern char banim_grkm_sp1_motion_o;
extern char banim_grkm_sp1_oam_r_bin;
extern char banim_grkm_sp1_oam_l_bin;
extern char banim_grkm_sp1_agbpal;
// battle animation 0x4F
extern int banim_grkm_ax1_modes_bin;
extern char banim_grkm_ax1_motion_o;
extern char banim_grkm_ax1_oam_r_bin;
extern char banim_grkm_ax1_oam_l_bin;
extern char banim_grkm_ax1_agbpal;
// battle animation 0x50
extern int banim_grkm_ax1_2_modes_bin;
extern char banim_grkm_ax1_2_motion_o;
extern char banim_grkm_ax1_2_oam_r_bin;
extern char banim_grkm_ax1_2_oam_l_bin;
extern char banim_grkm_ax1_2_agbpal;
// battle animation 0x51
extern int banim_grkm_sw1_2_modes_bin;
extern char banim_grkm_sw1_2_motion_o;
extern char banim_grkm_sw1_2_oam_r_bin;
extern char banim_grkm_sw1_2_oam_l_bin;
extern char banim_grkm_sw1_2_agbpal;
// battle animation 0x52
extern int banim_grkm_sw1_3_modes_bin;
extern char banim_grkm_sw1_3_motion_o;
extern char banim_grkm_sw1_3_oam_r_bin;
extern char banim_grkm_sw1_3_oam_l_bin;
extern char banim_grkm_sw1_3_agbpal;
// battle animation 0x53
extern int banim_grkm_sp1_2_modes_bin;
extern char banim_grkm_sp1_2_motion_o;
extern char banim_grkm_sp1_2_oam_r_bin;
extern char banim_grkm_sp1_2_oam_l_bin;
extern char banim_grkm_sp1_2_agbpal;
// battle animation 0x54
extern int banim_grkm_ax1_3_modes_bin;
extern char banim_grkm_ax1_3_motion_o;
extern char banim_grkm_ax1_3_oam_r_bin;
extern char banim_grkm_ax1_3_oam_l_bin;
extern char banim_grkm_ax1_3_agbpal;
// battle animation 0x55
extern int banim_grkm_ax1_4_modes_bin;
extern char banim_grkm_ax1_4_motion_o;
extern char banim_grkm_ax1_4_oam_r_bin;
extern char banim_grkm_ax1_4_oam_l_bin;
extern char banim_grkm_ax1_4_agbpal;
// battle animation 0x56
extern int banim_grkm_sw1_4_modes_bin;
extern char banim_grkm_sw1_4_motion_o;
extern char banim_grkm_sw1_4_oam_r_bin;
extern char banim_grkm_sw1_4_oam_l_bin;
extern char banim_grkm_sw1_4_agbpal;
// battle animation 0x57
extern int banim_drkm_sp1_modes_bin;
extern char banim_drkm_sp1_motion_o;
extern char banim_drkm_sp1_oam_r_bin;
extern char banim_drkm_sp1_oam_l_bin;
extern char banim_drkm_sp1_agbpal;
// battle animation 0x58
extern int banim_drkm_sp1_2_modes_bin;
extern char banim_drkm_sp1_2_motion_o;
extern char banim_drkm_sp1_2_oam_r_bin;
extern char banim_drkm_sp1_2_oam_l_bin;
extern char banim_drkm_sp1_2_agbpal;
// battle animation 0x59
extern int banim_drkm_sp1_3_modes_bin;
extern char banim_drkm_sp1_3_motion_o;
extern char banim_drkm_sp1_3_oam_r_bin;
extern char banim_drkm_sp1_3_oam_l_bin;
extern char banim_drkm_sp1_3_agbpal;
// battle animation 0x5A
extern int banim_drkm_sp1_4_modes_bin;
extern char banim_drkm_sp1_4_motion_o;
extern char banim_drkm_sp1_4_oam_r_bin;
extern char banim_drkm_sp1_4_oam_l_bin;
extern char banim_drkm_sp1_4_agbpal;
// battle animation 0x5B
extern int banim_drmm_sp1_modes_bin;
extern char banim_drmm_sp1_motion_o;
extern char banim_drmm_sp1_oam_r_bin;
extern char banim_drmm_sp1_oam_l_bin;
extern char banim_drmm_sp1_agbpal;
// battle animation 0x5C
extern int banim_drmm_sp1_2_modes_bin;
extern char banim_drmm_sp1_2_motion_o;
extern char banim_drmm_sp1_2_oam_r_bin;
extern char banim_drmm_sp1_2_oam_l_bin;
extern char banim_drmm_sp1_2_agbpal;
// battle animation 0x5D
extern int banim_drmm_sp1_3_modes_bin;
extern char banim_drmm_sp1_3_motion_o;
extern char banim_drmm_sp1_3_oam_r_bin;
extern char banim_drmm_sp1_3_oam_l_bin;
extern char banim_drmm_sp1_3_agbpal;
// battle animation 0x5E
extern int banim_drmm_sp1_4_modes_bin;
extern char banim_drmm_sp1_4_motion_o;
extern char banim_drmm_sp1_4_oam_r_bin;
extern char banim_drmm_sp1_4_oam_l_bin;
extern char banim_drmm_sp1_4_agbpal;
// battle animation 0x5F
extern int banim_drmm_sp1_5_modes_bin;
extern char banim_drmm_sp1_5_motion_o;
extern char banim_drmm_sp1_5_oam_r_bin;
extern char banim_drmm_sp1_5_oam_l_bin;
extern char banim_drmm_sp1_5_agbpal;
// battle animation 0x60
extern int banim_drmm_sp1_6_modes_bin;
extern char banim_drmm_sp1_6_motion_o;
extern char banim_drmm_sp1_6_oam_r_bin;
extern char banim_drmm_sp1_6_oam_l_bin;
extern char banim_drmm_sp1_6_agbpal;
// battle animation 0x61
extern int banim_wykm_sp1_modes_bin;
extern char banim_wykm_sp1_motion_o;
extern char banim_wykm_sp1_oam_r_bin;
extern char banim_wykm_sp1_oam_l_bin;
extern char banim_wykm_sp1_agbpal;
// battle animation 0x62
extern int banim_wykm_sp1_2_modes_bin;
extern char banim_wykm_sp1_2_motion_o;
extern char banim_wykm_sp1_2_oam_r_bin;
extern char banim_wykm_sp1_2_oam_l_bin;
extern char banim_wykm_sp1_2_agbpal;
// battle animation 0x63
extern int banim_wykm_sp1_3_modes_bin;
extern char banim_wykm_sp1_3_motion_o;
extern char banim_wykm_sp1_3_oam_r_bin;
extern char banim_wykm_sp1_3_oam_l_bin;
extern char banim_wykm_sp1_3_agbpal;
// battle animation 0x64
extern int banim_wykm_sp1_4_modes_bin;
extern char banim_wykm_sp1_4_motion_o;
extern char banim_wykm_sp1_4_oam_r_bin;
extern char banim_wykm_sp1_4_oam_l_bin;
extern char banim_wykm_sp1_4_agbpal;
// battle animation 0x65
extern int banim_pekf_sp1_modes_bin;
extern char banim_pekf_sp1_motion_o;
extern char banim_pekf_sp1_oam_r_bin;
extern char banim_pekf_sp1_oam_l_bin;
extern char banim_pekf_sp1_agbpal;
// battle animation 0x66
extern int banim_pekf_sp1_2_modes_bin;
extern char banim_pekf_sp1_2_motion_o;
extern char banim_pekf_sp1_2_oam_r_bin;
extern char banim_pekf_sp1_2_oam_l_bin;
extern char banim_pekf_sp1_2_agbpal;
// battle animation 0x67
extern int banim_fakf_sp1_modes_bin;
extern char banim_fakf_sp1_motion_o;
extern char banim_fakf_sp1_oam_r_bin;
extern char banim_fakf_sp1_oam_l_bin;
extern char banim_fakf_sp1_agbpal;
// battle animation 0x68
extern int banim_fakf_sp1_2_modes_bin;
extern char banim_fakf_sp1_2_motion_o;
extern char banim_fakf_sp1_2_oam_r_bin;
extern char banim_fakf_sp1_2_oam_l_bin;
extern char banim_fakf_sp1_2_agbpal;
// battle animation 0x69
extern int banim_fakf_sp1_3_modes_bin;
extern char banim_fakf_sp1_3_motion_o;
extern char banim_fakf_sp1_3_oam_r_bin;
extern char banim_fakf_sp1_3_oam_l_bin;
extern char banim_fakf_sp1_3_agbpal;
// battle animation 0x6A
extern int banim_magm_mg1_modes_bin;
extern char banim_magm_mg1_motion_o;
extern char banim_magm_mg1_oam_r_bin;
extern char banim_magm_mg1_oam_l_bin;
extern char banim_magm_mg1_agbpal;
// battle animation 0x6B
extern int banim_magf_mg1_modes_bin;
extern char banim_magf_mg1_motion_o;
extern char banim_magf_mg1_oam_r_bin;
extern char banim_magf_mg1_oam_l_bin;
extern char banim_magf_mg1_agbpal;
// battle animation 0x6C
extern int banim_sagm_mg1_modes_bin;
extern char banim_sagm_mg1_motion_o;
extern char banim_sagm_mg1_oam_r_bin;
extern char banim_sagm_mg1_oam_l_bin;
extern char banim_sagm_mg1_agbpal;
// battle animation 0x6D
extern int banim_sagm_mg1_2_modes_bin;
extern char banim_sagm_mg1_2_motion_o;
extern char banim_sagm_mg1_2_oam_r_bin;
extern char banim_sagm_mg1_2_oam_l_bin;
extern char banim_sagm_mg1_2_agbpal;
// battle animation 0x6E
extern int banim_sagf_mg1_modes_bin;
extern char banim_sagf_mg1_motion_o;
extern char banim_sagf_mg1_oam_r_bin;
extern char banim_sagf_mg1_oam_l_bin;
extern char banim_sagf_mg1_agbpal;
// battle animation 0x6F
extern int banim_sagf_mg1_2_modes_bin;
extern char banim_sagf_mg1_2_motion_o;
extern char banim_sagf_mg1_2_oam_r_bin;
extern char banim_sagf_mg1_2_oam_l_bin;
extern char banim_sagf_mg1_2_agbpal;
// battle animation 0x70
extern int banim_mgkm_mg1_modes_bin;
extern char banim_mgkm_mg1_motion_o;
extern char banim_mgkm_mg1_oam_r_bin;
extern char banim_mgkm_mg1_oam_l_bin;
extern char banim_mgkm_mg1_agbpal;
// battle animation 0x71
extern int banim_mgkm_mg1_2_modes_bin;
extern char banim_mgkm_mg1_2_motion_o;
extern char banim_mgkm_mg1_2_oam_r_bin;
extern char banim_mgkm_mg1_2_oam_l_bin;
extern char banim_mgkm_mg1_2_agbpal;
// battle animation 0x72
extern int banim_mgkf_mg1_modes_bin;
extern char banim_mgkf_mg1_motion_o;
extern char banim_mgkf_mg1_oam_r_bin;
extern char banim_mgkf_mg1_oam_l_bin;
extern char banim_mgkf_mg1_agbpal;
// battle animation 0x73
extern int banim_mgkf_mg1_2_modes_bin;
extern char banim_mgkf_mg1_2_motion_o;
extern char banim_mgkf_mg1_2_oam_r_bin;
extern char banim_mgkf_mg1_2_oam_l_bin;
extern char banim_mgkf_mg1_2_agbpal;
// battle animation 0x74
extern int banim_sham_mg1_modes_bin;
extern char banim_sham_mg1_motion_o;
extern char banim_sham_mg1_oam_r_bin;
extern char banim_sham_mg1_oam_l_bin;
extern char banim_sham_mg1_agbpal;
// battle animation 0x75
extern int banim_shaf_mg1_modes_bin;
extern char banim_shaf_mg1_motion_o;
extern char banim_shaf_mg1_oam_r_bin;
extern char banim_shaf_mg1_oam_l_bin;
extern char banim_shaf_mg1_agbpal;
// battle animation 0x76
extern int banim_drum_mg1_modes_bin;
extern char banim_drum_mg1_motion_o;
extern char banim_drum_mg1_oam_r_bin;
extern char banim_drum_mg1_oam_l_bin;
extern char banim_drum_mg1_agbpal;
// battle animation 0x77
extern int banim_drum_mg1_2_modes_bin;
extern char banim_drum_mg1_2_motion_o;
extern char banim_drum_mg1_2_oam_r_bin;
extern char banim_drum_mg1_2_oam_l_bin;
extern char banim_drum_mg1_2_agbpal;
// battle animation 0x78
extern int banim_druf_mg1_modes_bin;
extern char banim_druf_mg1_motion_o;
extern char banim_druf_mg1_oam_r_bin;
extern char banim_druf_mg1_oam_l_bin;
extern char banim_druf_mg1_agbpal;
// battle animation 0x79
extern int banim_druf_mg1_2_modes_bin;
extern char banim_druf_mg1_2_motion_o;
extern char banim_druf_mg1_2_oam_r_bin;
extern char banim_druf_mg1_2_oam_l_bin;
extern char banim_druf_mg1_2_agbpal;
// battle animation 0x7A
extern int banim_smnm_ro1_modes_bin;
extern char banim_smnm_ro1_motion_o;
extern char banim_smnm_ro1_oam_r_bin;
extern char banim_smnm_ro1_oam_l_bin;
extern char banim_smnm_ro1_agbpal;
// battle animation 0x7B
extern int banim_smnm_ro1_2_modes_bin;
extern char banim_smnm_ro1_2_motion_o;
extern char banim_smnm_ro1_2_oam_r_bin;
extern char banim_smnm_ro1_2_oam_l_bin;
extern char banim_smnm_ro1_2_agbpal;
// battle animation 0x7C
extern int banim_monm_mg1_modes_bin;
extern char banim_monm_mg1_motion_o;
extern char banim_monm_mg1_oam_r_bin;
extern char banim_monm_mg1_oam_l_bin;
extern char banim_monm_mg1_agbpal;
// battle animation 0x7D
extern int banim_prim_ro1_modes_bin;
extern char banim_prim_ro1_motion_o;
extern char banim_prim_ro1_oam_r_bin;
extern char banim_prim_ro1_oam_l_bin;
extern char banim_prim_ro1_agbpal;
// battle animation 0x7E
extern int banim_prim_ro1_2_modes_bin;
extern char banim_prim_ro1_2_motion_o;
extern char banim_prim_ro1_2_oam_r_bin;
extern char banim_prim_ro1_2_oam_l_bin;
extern char banim_prim_ro1_2_agbpal;
// battle animation 0x7F
extern int banim_prif_ro1_modes_bin;
extern char banim_prif_ro1_motion_o;
extern char banim_prif_ro1_oam_r_bin;
extern char banim_prif_ro1_oam_l_bin;
extern char banim_prif_ro1_agbpal;
// battle animation 0x80
extern int banim_bism_mg1_modes_bin;
extern char banim_bism_mg1_motion_o;
extern char banim_bism_mg1_oam_r_bin;
extern char banim_bism_mg1_oam_l_bin;
extern char banim_bism_mg1_agbpal;
// battle animation 0x81
extern int banim_bism_mg1_2_modes_bin;
extern char banim_bism_mg1_2_motion_o;
extern char banim_bism_mg1_2_oam_r_bin;
extern char banim_bism_mg1_2_oam_l_bin;
extern char banim_bism_mg1_2_agbpal;
// battle animation 0x82
extern int banim_bisf_mg1_modes_bin;
extern char banim_bisf_mg1_motion_o;
extern char banim_bisf_mg1_oam_r_bin;
extern char banim_bisf_mg1_oam_l_bin;
extern char banim_bisf_mg1_agbpal;
// battle animation 0x83
extern int banim_bisf_mg1_2_modes_bin;
extern char banim_bisf_mg1_2_motion_o;
extern char banim_bisf_mg1_2_oam_r_bin;
extern char banim_bisf_mg1_2_oam_l_bin;
extern char banim_bisf_mg1_2_agbpal;
// battle animation 0x84
extern int banim_trof_ro1_modes_bin;
extern char banim_trof_ro1_motion_o;
extern char banim_trof_ro1_oam_r_bin;
extern char banim_trof_ro1_oam_l_bin;
extern char banim_trof_ro1_agbpal;
// battle animation 0x85
extern int banim_trof_ro1_2_modes_bin;
extern char banim_trof_ro1_2_motion_o;
extern char banim_trof_ro1_2_oam_r_bin;
extern char banim_trof_ro1_2_oam_l_bin;
extern char banim_trof_ro1_2_agbpal;
// battle animation 0x86
extern int banim_valf_mg1_modes_bin;
extern char banim_valf_mg1_motion_o;
extern char banim_valf_mg1_oam_r_bin;
extern char banim_valf_mg1_oam_l_bin;
extern char banim_valf_mg1_agbpal;
// battle animation 0x87
extern int banim_valf_mg1_2_modes_bin;
extern char banim_valf_mg1_2_motion_o;
extern char banim_valf_mg1_2_oam_r_bin;
extern char banim_valf_mg1_2_oam_l_bin;
extern char banim_valf_mg1_2_agbpal;
// battle animation 0x88
extern int banim_thim_sw1_modes_bin;
extern char banim_thim_sw1_motion_o;
extern char banim_thim_sw1_oam_r_bin;
extern char banim_thim_sw1_oam_l_bin;
extern char banim_thim_sw1_agbpal;
// battle animation 0x89
extern int banim_thim_sw1_2_modes_bin;
extern char banim_thim_sw1_2_motion_o;
extern char banim_thim_sw1_2_oam_r_bin;
extern char banim_thim_sw1_2_oam_l_bin;
extern char banim_thim_sw1_2_agbpal;
// battle animation 0x8A
extern int banim_asnm_sw1_modes_bin;
extern char banim_asnm_sw1_motion_o;
extern char banim_asnm_sw1_oam_r_bin;
extern char banim_asnm_sw1_oam_l_bin;
extern char banim_asnm_sw1_agbpal;
// battle animation 0x8B
extern int banim_asnm_sw1_2_modes_bin;
extern char banim_asnm_sw1_2_motion_o;
extern char banim_asnm_sw1_2_oam_r_bin;
extern char banim_asnm_sw1_2_oam_l_bin;
extern char banim_asnm_sw1_2_agbpal;
// battle animation 0x8C
extern int banim_asnm_sw1_3_modes_bin;
extern char banim_asnm_sw1_3_motion_o;
extern char banim_asnm_sw1_3_oam_r_bin;
extern char banim_asnm_sw1_3_oam_l_bin;
extern char banim_asnm_sw1_3_agbpal;
// battle animation 0x8D
extern int banim_asnm_sw1_4_modes_bin;
extern char banim_asnm_sw1_4_motion_o;
extern char banim_asnm_sw1_4_oam_r_bin;
extern char banim_asnm_sw1_4_oam_l_bin;
extern char banim_asnm_sw1_4_agbpal;
// battle animation 0x8E
extern int banim_rogm_sw1_modes_bin;
extern char banim_rogm_sw1_motion_o;
extern char banim_rogm_sw1_oam_r_bin;
extern char banim_rogm_sw1_oam_l_bin;
extern char banim_rogm_sw1_agbpal;
// battle animation 0x8F
extern int banim_rogm_sw1_2_modes_bin;
extern char banim_rogm_sw1_2_motion_o;
extern char banim_rogm_sw1_2_oam_r_bin;
extern char banim_rogm_sw1_2_oam_l_bin;
extern char banim_rogm_sw1_2_agbpal;
// battle animation 0x90
extern int banim_danf_da1_modes_bin;
extern char banim_danf_da1_motion_o;
extern char banim_danf_da1_oam_r_bin;
extern char banim_danf_da1_oam_l_bin;
extern char banim_danf_da1_agbpal;
// battle animation 0x91
extern int banim_pbfm_ax1_modes_bin;
extern char banim_pbfm_ax1_motion_o;
extern char banim_pbfm_ax1_oam_r_bin;
extern char banim_pbfm_ax1_oam_l_bin;
extern char banim_pbfm_ax1_agbpal;
// battle animation 0x92
extern int banim_pbfm_ax1_2_modes_bin;
extern char banim_pbfm_ax1_2_motion_o;
extern char banim_pbfm_ax1_2_oam_r_bin;
extern char banim_pbfm_ax1_2_oam_l_bin;
extern char banim_pbfm_ax1_2_agbpal;
// battle animation 0x93
extern int banim_pbfm_ax1_3_modes_bin;
extern char banim_pbfm_ax1_3_motion_o;
extern char banim_pbfm_ax1_3_oam_r_bin;
extern char banim_pbfm_ax1_3_oam_l_bin;
extern char banim_pbfm_ax1_3_agbpal;
// battle animation 0x94
extern int banim_pbmm_mg1_modes_bin;
extern char banim_pbmm_mg1_motion_o;
extern char banim_pbmm_mg1_oam_r_bin;
extern char banim_pbmm_mg1_oam_l_bin;
extern char banim_pbmm_mg1_agbpal;
// battle animation 0x95
extern int banim_pbrf_sp1_modes_bin;
extern char banim_pbrf_sp1_motion_o;
extern char banim_pbrf_sp1_oam_r_bin;
extern char banim_pbrf_sp1_oam_l_bin;
extern char banim_pbrf_sp1_agbpal;
// battle animation 0x96
extern int banim_pbrf_sp1_2_modes_bin;
extern char banim_pbrf_sp1_2_motion_o;
extern char banim_pbrf_sp1_2_oam_r_bin;
extern char banim_pbrf_sp1_2_oam_l_bin;
extern char banim_pbrf_sp1_2_agbpal;
// battle animation 0x97
extern int banim_solm_sp1_modes_bin;
extern char banim_solm_sp1_motion_o;
extern char banim_solm_sp1_oam_r_bin;
extern char banim_solm_sp1_oam_l_bin;
extern char banim_solm_sp1_agbpal;
// battle animation 0x98
extern int banim_solm_sp1_2_modes_bin;
extern char banim_solm_sp1_2_motion_o;
extern char banim_solm_sp1_2_oam_r_bin;
extern char banim_solm_sp1_2_oam_l_bin;
extern char banim_solm_sp1_2_agbpal;
// battle animation 0x99
extern int banim_pirm_ax1_modes_bin;
extern char banim_pirm_ax1_motion_o;
extern char banim_pirm_ax1_oam_r_bin;
extern char banim_pirm_ax1_oam_l_bin;
extern char banim_pirm_ax1_agbpal;
// battle animation 0x9A
extern int banim_pirm_ax1_2_modes_bin;
extern char banim_pirm_ax1_2_motion_o;
extern char banim_pirm_ax1_2_oam_r_bin;
extern char banim_pirm_ax1_2_oam_l_bin;
extern char banim_pirm_ax1_2_agbpal;
// battle animation 0x9B
extern int banim_pirm_ax1_3_modes_bin;
extern char banim_pirm_ax1_3_motion_o;
extern char banim_pirm_ax1_3_oam_r_bin;
extern char banim_pirm_ax1_3_oam_l_bin;
extern char banim_pirm_ax1_3_agbpal;
// battle animation 0x9C
extern int banim_necm_mg1_modes_bin;
extern char banim_necm_mg1_motion_o;
extern char banim_necm_mg1_oam_r_bin;
extern char banim_necm_mg1_oam_l_bin;
extern char banim_necm_mg1_agbpal;
// battle animation 0x9D
extern int banim_necm_ro1_modes_bin;
extern char banim_necm_ro1_motion_o;
extern char banim_necm_ro1_oam_r_bin;
extern char banim_necm_ro1_oam_l_bin;
extern char banim_necm_ro1_agbpal;
// battle animation 0x9E
extern int banim_stam_ar1_modes_bin;
extern char banim_stam_ar1_motion_o;
extern char banim_stam_ar1_oam_r_bin;
extern char banim_stam_ar1_oam_l_bin;
extern char banim_stam_ar1_agbpal;
// battle animation 0x9F
extern int banim_zom_at1_modes_bin;
extern char banim_zom_at1_motion_o;
extern char banim_zom_at1_oam_r_bin;
extern char banim_zom_at1_oam_l_bin;
extern char banim_zom_at1_agbpal;
// battle animation 0xA0
extern int banim_zom_at1_2_modes_bin;
extern char banim_zom_at1_2_motion_o;
extern char banim_zom_at1_2_oam_r_bin;
extern char banim_zom_at1_2_oam_l_bin;
extern char banim_zom_at1_2_agbpal;
// battle animation 0xA1
extern int banim_sks_sw1_modes_bin;
extern char banim_sks_sw1_motion_o;
extern char banim_sks_sw1_oam_r_bin;
extern char banim_sks_sw1_oam_l_bin;
extern char banim_sks_sw1_agbpal;
// battle animation 0xA2
extern int banim_sks_sp1_modes_bin;
extern char banim_sks_sp1_motion_o;
extern char banim_sks_sp1_oam_r_bin;
extern char banim_sks_sp1_oam_l_bin;
extern char banim_sks_sp1_agbpal;
// battle animation 0xA3
extern int banim_sks_sw1_2_modes_bin;
extern char banim_sks_sw1_2_motion_o;
extern char banim_sks_sw1_2_oam_r_bin;
extern char banim_sks_sw1_2_oam_l_bin;
extern char banim_sks_sw1_2_agbpal;
// battle animation 0xA4
extern int banim_ska_ar1_modes_bin;
extern char banim_ska_ar1_motion_o;
extern char banim_ska_ar1_oam_r_bin;
extern char banim_ska_ar1_oam_l_bin;
extern char banim_ska_ar1_agbpal;
// battle animation 0xA5
extern int banim_sks_sw1_3_modes_bin;
extern char banim_sks_sw1_3_motion_o;
extern char banim_sks_sw1_3_oam_r_bin;
extern char banim_sks_sw1_3_oam_l_bin;
extern char banim_sks_sw1_3_agbpal;
// battle animation 0xA6
extern int banim_sks_sw1_4_modes_bin;
extern char banim_sks_sw1_4_motion_o;
extern char banim_sks_sw1_4_oam_r_bin;
extern char banim_sks_sw1_4_oam_l_bin;
extern char banim_sks_sw1_4_agbpal;
// battle animation 0xA7
extern int banim_sks_sp1_2_modes_bin;
extern char banim_sks_sp1_2_motion_o;
extern char banim_sks_sp1_2_oam_r_bin;
extern char banim_sks_sp1_2_oam_l_bin;
extern char banim_sks_sp1_2_agbpal;
// battle animation 0xA8
extern int banim_sks_sw1_5_modes_bin;
extern char banim_sks_sw1_5_motion_o;
extern char banim_sks_sw1_5_oam_r_bin;
extern char banim_sks_sw1_5_oam_l_bin;
extern char banim_sks_sw1_5_agbpal;
// battle animation 0xA9
extern int banim_ska_ar1_2_modes_bin;
extern char banim_ska_ar1_2_motion_o;
extern char banim_ska_ar1_2_oam_r_bin;
extern char banim_ska_ar1_2_oam_l_bin;
extern char banim_ska_ar1_2_agbpal;
// battle animation 0xAA
extern int banim_sks_sw1_6_modes_bin;
extern char banim_sks_sw1_6_motion_o;
extern char banim_sks_sw1_6_oam_r_bin;
extern char banim_sks_sw1_6_oam_l_bin;
extern char banim_sks_sw1_6_agbpal;
// battle animation 0xAB
extern int banim_bae_at1_modes_bin;
extern char banim_bae_at1_motion_o;
extern char banim_bae_at1_oam_r_bin;
extern char banim_bae_at1_oam_l_bin;
extern char banim_bae_at1_agbpal;
// battle animation 0xAC
extern int banim_bae_at1_2_modes_bin;
extern char banim_bae_at1_2_motion_o;
extern char banim_bae_at1_2_oam_r_bin;
extern char banim_bae_at1_2_oam_l_bin;
extern char banim_bae_at1_2_agbpal;
// battle animation 0xAD
extern int banim_cyc_ax1_modes_bin;
extern char banim_cyc_ax1_motion_o;
extern char banim_cyc_ax1_oam_r_bin;
extern char banim_cyc_ax1_oam_l_bin;
extern char banim_cyc_ax1_agbpal;
// battle animation 0xAE
extern int banim_cyc_ax1_2_modes_bin;
extern char banim_cyc_ax1_2_motion_o;
extern char banim_cyc_ax1_2_oam_r_bin;
extern char banim_cyc_ax1_2_oam_l_bin;
extern char banim_cyc_ax1_2_agbpal;
// battle animation 0xAF
extern int banim_cyc_ax1_3_modes_bin;
extern char banim_cyc_ax1_3_motion_o;
extern char banim_cyc_ax1_3_oam_r_bin;
extern char banim_cyc_ax1_3_oam_l_bin;
extern char banim_cyc_ax1_3_agbpal;
// battle animation 0xB0
extern int banim_mdg_at1_modes_bin;
extern char banim_mdg_at1_motion_o;
extern char banim_mdg_at1_oam_r_bin;
extern char banim_mdg_at1_oam_l_bin;
extern char banim_mdg_at1_agbpal;
// battle animation 0xB1
extern int banim_cer_at1_modes_bin;
extern char banim_cer_at1_motion_o;
extern char banim_cer_at1_oam_r_bin;
extern char banim_cer_at1_oam_l_bin;
extern char banim_cer_at1_agbpal;
// battle animation 0xB2
extern int banim_mcd_ax1_modes_bin;
extern char banim_mcd_ax1_motion_o;
extern char banim_mcd_ax1_oam_r_bin;
extern char banim_mcd_ax1_oam_l_bin;
extern char banim_mcd_ax1_agbpal;
// battle animation 0xB3
extern int banim_mcd_ax1_2_modes_bin;
extern char banim_mcd_ax1_2_motion_o;
extern char banim_mcd_ax1_2_oam_r_bin;
extern char banim_mcd_ax1_2_oam_l_bin;
extern char banim_mcd_ax1_2_agbpal;
// battle animation 0xB4
extern int banim_mcd_ax1_3_modes_bin;
extern char banim_mcd_ax1_3_motion_o;
extern char banim_mcd_ax1_3_oam_r_bin;
extern char banim_mcd_ax1_3_oam_l_bin;
extern char banim_mcd_ax1_3_agbpal;
// battle animation 0xB5
extern int banim_mcd_ax1_4_modes_bin;
extern char banim_mcd_ax1_4_motion_o;
extern char banim_mcd_ax1_4_oam_r_bin;
extern char banim_mcd_ax1_4_oam_l_bin;
extern char banim_mcd_ax1_4_agbpal;
// battle animation 0xB6
extern int banim_mcd_ax1_5_modes_bin;
extern char banim_mcd_ax1_5_motion_o;
extern char banim_mcd_ax1_5_oam_r_bin;
extern char banim_mcd_ax1_5_oam_l_bin;
extern char banim_mcd_ax1_5_agbpal;
// battle animation 0xB7
extern int banim_mcd_ar1_modes_bin;
extern char banim_mcd_ar1_motion_o;
extern char banim_mcd_ar1_oam_r_bin;
extern char banim_mcd_ar1_oam_l_bin;
extern char banim_mcd_ar1_agbpal;
// battle animation 0xB8
extern int banim_mcd_ax1_6_modes_bin;
extern char banim_mcd_ax1_6_motion_o;
extern char banim_mcd_ax1_6_oam_r_bin;
extern char banim_mcd_ax1_6_oam_l_bin;
extern char banim_mcd_ax1_6_agbpal;
// battle animation 0xB9
extern int banim_bgl_mg1_modes_bin;
extern char banim_bgl_mg1_motion_o;
extern char banim_bgl_mg1_oam_r_bin;
extern char banim_bgl_mg1_oam_l_bin;
extern char banim_bgl_mg1_agbpal;
// battle animation 0xBA
extern int banim_bgl_mg1_2_modes_bin;
extern char banim_bgl_mg1_2_motion_o;
extern char banim_bgl_mg1_2_oam_r_bin;
extern char banim_bgl_mg1_2_oam_l_bin;
extern char banim_bgl_mg1_2_agbpal;
// battle animation 0xBB
extern int banim_gog_mg1_modes_bin;
extern char banim_gog_mg1_motion_o;
extern char banim_gog_mg1_oam_r_bin;
extern char banim_gog_mg1_oam_l_bin;
extern char banim_gog_mg1_agbpal;
// battle animation 0xBC
extern int banim_gar_sp1_modes_bin;
extern char banim_gar_sp1_motion_o;
extern char banim_gar_sp1_oam_r_bin;
extern char banim_gar_sp1_oam_l_bin;
extern char banim_gar_sp1_agbpal;
// battle animation 0xBD
extern int banim_gar_sp1_2_modes_bin;
extern char banim_gar_sp1_2_motion_o;
extern char banim_gar_sp1_2_oam_r_bin;
extern char banim_gar_sp1_2_oam_l_bin;
extern char banim_gar_sp1_2_agbpal;
// battle animation 0xBE
extern int banim_gar_sp1_3_modes_bin;
extern char banim_gar_sp1_3_motion_o;
extern char banim_gar_sp1_3_oam_r_bin;
extern char banim_gar_sp1_3_oam_l_bin;
extern char banim_gar_sp1_3_agbpal;
// battle animation 0xBF
extern int banim_gar_sp1_4_modes_bin;
extern char banim_gar_sp1_4_motion_o;
extern char banim_gar_sp1_4_oam_r_bin;
extern char banim_gar_sp1_4_oam_l_bin;
extern char banim_gar_sp1_4_agbpal;
// battle animation 0xC0
extern int banim_drz_mg1_modes_bin;
extern char banim_drz_mg1_motion_o;
extern char banim_drz_mg1_oam_r_bin;
extern char banim_drz_mg1_oam_l_bin;
extern char banim_drz_mg1_agbpal;
// battle animation 0xC1
extern int banim_bos_at1_modes_bin;
extern char banim_bos_at1_motion_o;
extern char banim_bos_at1_oam_r_bin;
extern char banim_bos_at1_oam_l_bin;
extern char banim_bos_at1_agbpal;
// battle animation 0xC2
extern int banim_bos_at1_2_modes_bin;
extern char banim_bos_at1_2_motion_o;
extern char banim_bos_at1_2_oam_r_bin;
extern char banim_bos_at1_2_oam_l_bin;
extern char banim_bos_at1_2_agbpal;
// battle animation 0xC3
extern int banim_fifd_mg1_modes_bin;
extern char banim_fifd_mg1_motion_o;
extern char banim_fifd_mg1_oam_r_bin;
extern char banim_fifd_mg1_oam_l_bin;
extern char banim_fifd_mg1_agbpal;
// battle animation 0xC4
extern int banim_fifd_he1_modes_bin;
extern char banim_fifd_he1_motion_o;
extern char banim_fifd_he1_oam_r_bin;
extern char banim_fifd_he1_oam_l_bin;
extern char banim_fifd_he1_agbpal;
// battle animation 0xC5
extern int banim_fifd_hk1_modes_bin;
extern char banim_fifd_hk1_motion_o;
extern char banim_fifd_hk1_oam_r_bin;
extern char banim_fifd_hk1_oam_l_bin;
extern char banim_fifd_hk1_agbpal;
// battle animation 0xC6
extern int banim_mf_mi1_modes_bin;
extern char banim_mf_mi1_motion_o;
extern char banim_mf_mi1_oam_r_bin;
extern char banim_mf_mi1_oam_l_bin;
extern char banim_mf_mi1_agbpal;
// battle animation 0xC7
extern int banim_prif_ro1_2_modes_bin;
extern char banim_prif_ro1_2_motion_o;
extern char banim_prif_ro1_2_oam_r_bin;
extern char banim_prif_ro1_2_oam_l_bin;
extern char banim_prif_ro1_2_agbpal;
// battle animation 0xC8
extern int banim_fifd_mg1_2_modes_bin;
extern char banim_fifd_mg1_2_motion_o;
extern char banim_fifd_mg1_2_oam_r_bin;
extern char banim_fifd_mg1_2_oam_l_bin;
extern char banim_fifd_mg1_2_agbpal;
// character palette
extern char banim_pal_mer[];
extern char banim_pal_ame[];
extern char banim_pal_gil[];
extern char banim_pal_bre[];
extern char banim_pal_saa[];
extern char banim_pal_mar[];
extern char banim_pal_com[];
extern char banim_pal_jho[];
extern char banim_pal_bon[];
extern char banim_pal_baz[];
extern char banim_pal_ass[];
extern char banim_pal_nat[];
extern char banim_pal_mul[];
extern char banim_pal_irv[];
extern char banim_pal_ewa[];
extern char banim_pal_gar[];
extern char banim_pal_ros[];
extern char banim_pal_xys[];
extern char banim_pal_doz[];
extern char banim_pal_ros_2[];
extern char banim_pal_tet[];
extern char banim_pal_cug[];
extern char banim_pal_cug_2[];
extern char banim_pal_gle[];
extern char banim_pal_kno[];
extern char banim_pal_ewa_2[];
extern char banim_pal_tur[];
extern char banim_pal_van[];
extern char banim_pal_syr[];
extern char banim_pal_gar_2[];
extern char banim_pal_ros_3[];
extern char banim_pal_one[];
extern char banim_pal_xys_2[];
extern char banim_pal_mer_2[];
extern char banim_pal_ber[];
extern char banim_pal_ame_2[];
extern char banim_pal_gil_2[];
extern char banim_pal_vig[];
extern char banim_pal_tir[];
extern char banim_pal_for[];
extern char banim_pal_fra[];
extern char banim_pal_gil_3[];
extern char banim_pal_kyl[];
extern char banim_pal_ame_3[];
extern char banim_pal_dus[];
extern char banim_pal_aia[];
extern char banim_pal_lut[];
extern char banim_pal_ewa_3[];
extern char banim_pal_xys_3[];
extern char banim_pal_zon[];
extern char banim_pal_ewa_4[];
extern char banim_pal_lar[];
extern char banim_pal_lut_2[];
extern char banim_pal_cel[];
extern char banim_pal_ass_2[];
extern char banim_pal_jho_2[];
extern char banim_pal_mar_2[];
extern char banim_pal_ame_4[];
extern char banim_pal_for_2[];
extern char banim_pal_set[];
extern char banim_pal_fra_2[];
extern char banim_pal_kyl_2[];
extern char banim_pal_ols[];
extern char banim_pal_van_2[];
extern char banim_pal_tur_2[];
extern char banim_pal_ros_4[];
extern char banim_pal_nat_2[];
extern char banim_pal_com_2[];
extern char banim_pal_mul_2[];
extern char banim_pal_ren[];
extern char banim_pal_lut_3[];
extern char banim_pal_ass_3[];
extern char banim_pal_ewa_5[];
extern char banim_pal_kno_2[];
extern char banim_pal_mul_3[];
extern char banim_pal_sal[];
extern char banim_pal_ewa_6[];
extern char banim_pal_kno_3[];
extern char banim_pal_nov[];
extern char banim_pal_ewa_7[];
extern char banim_pal_kno_4[];
extern char banim_pal_hea[];
extern char banim_pal_mer_3[];
extern char banim_pal_ame_5[];
extern char banim_pal_fra_3[];
extern char banim_pal_kyl_3[];
extern char banim_pal_for_3[];
extern char banim_pal_mur[];
extern char banim_pal_ish[];
extern char banim_pal_hey[];
extern char banim_pal_fad[];
extern char banim_pal_jho_3[];
extern char banim_pal_mar_3[];
extern char banim_pal_com_3[];
extern char banim_pal_car[];
extern char banim_pal_lar_2[];
extern char banim_pal_nat_3[];
extern char banim_pal_lar_3[];
extern char banim_pal_gar_3[];
extern char banim_pal_ros_5[];
extern char banim_pal_bin[];
extern char banim_pal_tur_3[];
extern char banim_pal_van_3[];
extern char banim_pal_cug_3[];
extern char banim_pal_wal[];
extern char banim_pal_geb[];
extern char banim_pal_pab[];
extern char banim_pal_cet[];
// battle animation terrain
extern short battle_terrain_heichi1_pal[];
extern char battle_terrain_heichi1_tileset[];
extern short battle_terrain_arechi1_pal[];
extern char battle_terrain_arechi1_tileset[];
extern short battle_terrain_jyoumon1_pal[];
extern char battle_terrain_jyoumon1_tileset[];
extern short battle_terrain_bukiya1_pal[];
extern char battle_terrain_bukiya1_tileset[];
extern short battle_terrain_gake1_pal[];
extern char battle_terrain_gake1_tileset[];
extern short battle_terrain_gyokuza1_pal[];
extern char battle_terrain_gyokuza1_tileset[];
extern short battle_terrain_haikyo1_pal[];
extern char battle_terrain_haikyo1_tileset[];
extern short battle_terrain_hanebashi1_pal[];
extern char battle_terrain_hanebashi1_tileset[];
extern short battle_terrain_hasi1_pal[];
extern char battle_terrain_hasi1_tileset[];
extern short battle_terrain_sabaku1_pal[];
extern char battle_terrain_sabaku1_tileset[];
extern short battle_terrain_kawa1_pal[];
extern char battle_terrain_kawa1_tileset[];
extern short battle_terrain_mura1_pal[];
extern char battle_terrain_mura1_tileset[];
extern short battle_terrain_umi1_pal[];
extern char battle_terrain_umi1_tileset[];
extern short battle_terrain_mizuiumi1_pal[];
extern char battle_terrain_mizuiumi1_tileset[];
extern short battle_terrain_azukarijo1_pal[];
extern char battle_terrain_azukarijo1_tileset[];
extern short battle_terrain_douguya1_pal[];
extern char battle_terrain_douguya1_tileset[];
extern short battle_terrain_fukaimori1_pal[];
extern char battle_terrain_fukaimori1_tileset[];
extern short battle_terrain_michi1_pal[];
extern char battle_terrain_michi1_tileset[];
extern short battle_terrain_minka1_pal[];
extern char battle_terrain_minka1_tileset[];
extern short battle_terrain_mori1_pal[];
extern char battle_terrain_mori1_tileset[];
extern short battle_terrain_siroyuka1_pal[];
extern char battle_terrain_siroyuka1_tileset[];
extern short battle_terrain_sunachi1_pal[];
extern char battle_terrain_sunachi1_tileset[];
extern short battle_terrain_takaiyama1_pal[];
extern char battle_terrain_takaiyama1_tileset[];
extern short battle_terrain_toride1_pal[];
extern char battle_terrain_toride1_tileset[];
extern short battle_terrain_tougijou1_pal[];
extern char battle_terrain_tougijou1_tileset[];
extern short battle_terrain_yama1_pal[];
extern char battle_terrain_yama1_tileset[];
extern short battle_terrain_mahouyuka1_pal[];
extern char battle_terrain_mahouyuka1_tileset[];
extern short battle_terrain_kabe1_pal[];
extern char battle_terrain_kabe1_tileset[];
extern short battle_terrain_kowaretakabe_pal[];
extern char battle_terrain_kowaretakabe_tileset[];
extern short battle_terrain_kowaretakabe_pal_2[];
extern char battle_terrain_kowaretakabe_tileset_2[];
extern short battle_terrain_hasira1_pal[];
extern char battle_terrain_hasira1_tileset[];
extern short battle_terrain_takarabako1_pal[];
extern char battle_terrain_takarabako1_tileset[];
extern short battle_terrain_killerarechi_pal[];
extern char battle_terrain_killerarechi_tileset[];
extern short battle_terrain_mon1_pal[];
extern char battle_terrain_mon1_tileset[];
extern short battle_terrain_tuusintougi1_pal[];
extern char battle_terrain_tuusintougi1_tileset[];
extern short battle_terrain_mura1_pal_2[];
extern short battle_terrain_siroyuka1_pal_2[];
extern short battle_terrain_gyokuza1_pal_2[];
extern short battle_terrain_takarabako1_pal_2[];
extern short battle_terrain_kowaretakabe_pal_3[];
extern short battle_terrain_heichi1_pal_2[];
extern short battle_terrain_jyoumon1_pal_2[];
extern short battle_terrain_bukiya1_pal_2[];
extern short battle_terrain_gake1_pal_2[];
extern short battle_terrain_haikyo1_pal_2[];
extern short battle_terrain_hasi1_pal_2[];
extern short battle_terrain_kawa1_pal_2[];
extern short battle_terrain_mura1_pal_3[];
extern short battle_terrain_mizuiumi1_pal_2[];
extern short battle_terrain_douguya1_pal_2[];
extern short battle_terrain_fukaimori1_pal_2[];
extern short battle_terrain_michi1_pal_2[];
extern short battle_terrain_minka1_pal_2[];
extern short battle_terrain_mori1_pal_2[];
extern short battle_terrain_takaiyama1_pal_2[];
extern short battle_terrain_tougijou1_pal_2[];
extern short battle_terrain_yama1_pal_2[];
extern short battle_terrain_killerarechi_pal_2[];
extern short battle_terrain_toride1_pal_2[];
extern short battle_terrain_kawa1_pal_3[];
extern short battle_terrain_siroyuka1_pal_3[];
extern short battle_terrain_takarabako1_pal_3[];
extern short battle_terrain_kowaretakabe_pal_4[];
extern short battle_terrain_gyokuza1_pal_3[];
extern short battle_terrain_hasira1_pal_2[];
extern short battle_terrain_hasira1_pal_3[];
extern short battle_terrain_heichi1_pal_3[];
extern short battle_terrain_kawa1_pal_4[];
extern short battle_terrain_siroyuka1_pal_4[];
extern short battle_terrain_takarabako1_pal_4[];
extern short battle_terrain_kowaretakabe_pal_5[];
extern short battle_terrain_gyokuza1_pal_4[];
extern short battle_terrain_hasira1_pal_4[];
extern short battle_terrain_heichi1_pal_4[];
extern short battle_terrain_kawa1_pal_5[];
extern short battle_terrain_maruta1_pal[];
extern char battle_terrain_maruta1_tileset[];
extern short battle_terrain_hasi1_pal_3[];
extern short battle_terrain_mura1_pal_4[];
extern short battle_terrain_siroyuka1_pal_5[];
extern short battle_terrain_takarabako1_pal_5[];
extern short battle_terrain_kowaretakabe_pal_6[];
extern short battle_terrain_gyokuza1_pal_5[];
extern short battle_terrain_hasira1_pal_5[];
extern short battle_terrain_heichi1_pal_5[];
extern short battle_terrain_kawa1_pal_6[];
extern short battle_terrain_gake1_pal_3[];
extern short battle_terrain_siroyuka1_pal_6[];
extern short battle_terrain_takarabako1_pal_6[];
extern short battle_terrain_kowaretakabe_pal_7[];
extern short battle_terrain_gyokuza1_pal_6[];
extern short battle_terrain_hasira1_pal_6[];
extern short battle_terrain_heichi1_pal_6[];
extern short battle_terrain_mori1_pal_3[];
extern short battle_terrain_maruta1_pal_2[];
extern short battle_terrain_fune1_pal[];
extern char battle_terrain_fune1_tileset[];
extern short battle_terrain_mori1_pal_4[];
extern short battle_terrain_umi1_pal_2[];
extern short battle_terrain_gyokuza1_pal_7[];
extern short battle_terrain_gyokuza1_pal_8[];
extern short battle_terrain_kawa1_pal_7[];
extern short battle_terrain_hasi1_pal_4[];
extern short battle_terrain_gyokuza1_pal_9[];
extern short battle_terrain_yama1_pal_3[];
extern short battle_terrain_takaiyama1_pal_3[];
extern short battle_terrain_mizuiumi1_pal_3[];
