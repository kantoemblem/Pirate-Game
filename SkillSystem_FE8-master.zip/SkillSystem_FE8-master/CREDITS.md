Note: This list is incomplete and insufficiently organized. If you contributed
something that you'd like special recognition for, please make a pull request
adding yourself!

# Skill contributors

- circleseverywhere
- Tequila
- Colorz
- Rossendale
- StanH
- Leonarth
- 2WB
- Teraspark
- Darrman
- SD9k
- Kao
- blademaster
- Snakey1
- Zeta
- Kirb
- Sme
- Ganzap
- Mikey Seregon
- Vesly 
- Dragz
- Jopettajah

# Other

- 7743: various bugfixes
- RobertFPY, Pikmin1211, and Snakey1: Str/Mag Split Finalization

# Graphics

- Monkeybard, Black Mage
- Blaze: Stances
- vlak: Drives
- Pikmin1211: Miscellaneous
- 2WB: Miscellaneous
- Someone: Taker, Hone, Oath, Rouse, Guts, Strong Con, Rally Chaos, Hoarders Bane, Shrewd Potential, Eternal Vanity 
- Alice: Dancing/Heavy Blade, Dark Bargain, Soul Sap 
- VelvetKitsune: Initiative 
- Zaim: Indoor March
- Reds: Quick Riposte
- Dragz: Divinely Inspiring
- circleseverywhere: Skill Animations

